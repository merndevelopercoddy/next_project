"use strict";
exports.id = 987;
exports.ids = [987];
exports.modules = {

/***/ 9506:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4683);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const Categories = () => {
  const {
    0: categories,
    1: setCategories
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (0,_services__WEBPACK_IMPORTED_MODULE_1__/* .getCategories */ .CP)().then(res => setCategories(res));
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "bg-white shadow-lg rounded-lg text-black p-0 lg:p-8 pb-12 mb-12",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
      className: "text-center text-xl border-b mb-2",
      children: "Categories"
    }), categories.map(category => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
      href: `/category/${category.slug}`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
        className: "cursor-pointer text-indigo-800 hover:text-indigo-400 mb-3 pb-3 block border-b transition duration-200 text-lg font-bold",
        children: category.name
      })
    }, category.slug))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Categories);

/***/ }),

/***/ 8:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const PostCard = ({
  post
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "bg-white shadow-lg rounded-lg text-black p-0 lg:p-8 pb-12 mb-12",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
      className: "text-center text-3xl font-semibold hover:text-red-500 cursor-pointer transition duration-700 mb-8",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        href: `/post/${post.slug}`,
        children: post.title
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "block lg:flex text-center items-center justify-center mb-8 w-full",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "flex items-center justify-center mb-4 lg:mb-0 w-full lg:w-auto mr-8",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
          src: post.author.photo.url,
          alt: post.author.name,
          width: "40px"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
          className: "m-2",
          children: post.author.name
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
            src: "https://img.icons8.com/plasticine/100/000000/apple-calendar.png",
            width: "40px",
            height: "40px"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
          children: moment__WEBPACK_IMPORTED_MODULE_2___default()(post.createdAt).format("DD . MM . YYYY")
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "relative overflow-hidden shadow-md pb-80 mb-6 ",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
        src: post.featuredImage.url,
        alt: post.title,
        className: "object-top absolute w-full h-100 object-cover shadow-lg rounded-t-lg lg:rounded-lg"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("h1", {
        className: "text-justify ",
        children: [" ", post.excerpt, " "]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "text-center cursor-pointer",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        href: `/post/${post.slug}`,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
          className: "rounded-full bg-green-500 w-40 px-8 py-2 mt-7 text-white inline-block transition duration-500 hover:translate-y-1",
          children: "Batafsil"
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PostCard);

/***/ }),

/***/ 6014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4683);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







const PostWidget = ({
  slug,
  categories
}) => {
  const {
    0: relatedPosts,
    1: setRelatedPosts
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (slug) {
      (0,_services__WEBPACK_IMPORTED_MODULE_1__/* .getSimilarPosts */ .IQ)(categories, slug).then(res => setRelatedPosts(res));
    } else {
      (0,_services__WEBPACK_IMPORTED_MODULE_1__/* .getRecentPosts */ .no)().then(res => setRelatedPosts(res));
    }
  }, [slug]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    className: "bg-white shadow-lg rounded-lg text-black p-0 lg:p-8 pb-12 mb-12",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h3", {
      className: "text-center text-xl border-b mb-2",
      children: slug ? "Slug ochilgan holat" : "Asosiy sahifadasiz"
    }), relatedPosts.map(post => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: "flex items-center w-full mb-4",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "w-16 flex-none",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("img", {
          src: post.featuredImage.url,
          alt: post.title,
          className: "rounded-3xl align-middle"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "flex-grow ml-4",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
          children: moment__WEBPACK_IMPORTED_MODULE_2___default()(post.createdAt).format("MMM DD, YYYY")
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "flex-grow text-blue-700 hover:text-black font-bold text-xl",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
          href: `/post/${post.slug}`,
          children: post.title
        })
      })]
    }, post.title))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PostWidget);

/***/ }),

/***/ 4683:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jq": () => (/* binding */ getPosts),
/* harmony export */   "no": () => (/* binding */ getRecentPosts),
/* harmony export */   "IQ": () => (/* binding */ getSimilarPosts),
/* harmony export */   "CP": () => (/* binding */ getCategories),
/* harmony export */   "zb": () => (/* binding */ getPostDetails),
/* harmony export */   "rd": () => (/* binding */ submitComment),
/* harmony export */   "li": () => (/* binding */ getComments),
/* harmony export */   "zn": () => (/* binding */ getCategoryPost),
/* harmony export */   "mH": () => (/* binding */ getFeaturedPosts)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

const graphqlAPI = "https://api-us-east-1.graphcms.com/v2/cl06xy3960s2x01xrcnk38l2g/master";
const getPosts = async () => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
        query MyQuery {
  postsConnection {
    edges {
      node {
        author {
          bio
          name
          id
          photo {
            url
          }
        }
        createdAt
        slug
        title
        excerpt
        featuredImage {
          url
        }
      }
    }
  }
}

    `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query);
  return result.postsConnection.edges;
};
const getRecentPosts = async () => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetPostDetails(){
      posts(
        orderBy: createdAt_ASC
        last: 3
      ) {
          title
          featuredImage{
            url
          }
          createdAt
          slug
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query);
  return result.posts;
};
const getSimilarPosts = async (categories, slug) => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetPostDetails($slug: String! , $categories: [String!]){
      posts(
        where: {slug_not: $slug , AND: {categories_some: {slug_in: $categories}}}
        last: 3
      ) {
          title
          featuredImage{
            url
          }
          createdAt
          slug
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
    categories,
    slug
  });
  return result.posts;
};
const getCategories = async () => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query getCategories{
      categories{
        name
        slug
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query);
  return result.categories;
};
const getPostDetails = async slug => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetPostDetails($slug: String!){
      post(where:{slug: $slug}){
        author{
          bio
          name
          id
          photo{
            url
          }
        }
        createdAt
        slug
        title
        excerpt
        featuredImage{
          url
        }
        categories{
          slug
          name
        }
        content{
          raw
        }
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
    slug
  });
  return result.post;
};
const submitComment = async obj => {
  const result = await fetch('/api/comments', {
    method: "POST",
    headers: {
      "Content-Type": 'application/json'
    },
    body: JSON.stringify(obj)
  });
  return result.json;
};
const getComments = async slug => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetComments($slug: String!){
      comments(where: {post:{slug: $slug}}){
        name
        createdAt
        comment
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
    slug
  });
  return result.comments;
};
const getCategoryPost = async slug => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetCategoryPost($slug: String!){
      postsConnection(where:{categories_some:{slug: $slug}}){
        edges {
          node {
            author {
              bio
              name
              id
              photo {
                url
              }
            }
            createdAt
            slug
            title
            excerpt
            featuredImage {
              url
            }
            categories {
              name
              slug
            }
          }
        }
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query, {
    slug
  });
  return result.postsConnection.edges;
};
const getFeaturedPosts = async () => {
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query GetCategoryPost(){
      posts(where:{featuredPost:true}){
        author{
          name
          photo{
            url
          }
        }
        featuredImage{
          url
        }
        title
        slug
        createdAt
      }
    }
  `;
  const result = await (0,graphql_request__WEBPACK_IMPORTED_MODULE_0__.request)(graphqlAPI, query);
  return result.posts;
};

/***/ })

};
;